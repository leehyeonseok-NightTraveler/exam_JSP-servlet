package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class dataDBBean {
	
	private static dataDBBean instance = new dataDBBean();
	
	public static dataDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "scott";
		String password = "tiger";
		return DriverManager.getConnection(url, user, password);
	}
	
	public List<dataBean> getList() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from emp";
		List<dataBean> list = new ArrayList<dataBean>();
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				dataBean data = new dataBean();
				data.setEmpno(rs.getInt("empno"));
				data.setEname(rs.getString("ename"));
				data.setJob(rs.getString("job"));
				Object mgrObj = rs.getObject("mgr");
				if (mgrObj != null) {
					data.setMgr(((Number)mgrObj).intValue());
				} else {
					data.setMgr(null);
				}
				data.setHiredate(rs.getString("hiredate"));
				data.setSal(rs.getDouble("sal"));
				Object commObj = rs.getObject("comm");
				if (commObj != null) {
					data.setComm(((Number)commObj).intValue());
				} else {
					data.setComm(null);
				}
				data.setDeptno(rs.getInt("deptno"));
				list.add(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}